public class Main {
    public static void main(String[] args) {

        /*
Write a Java program to calculate the factorial of a number using recursion.
Write a Java program to check if a given number is prime or not.
Write a Java program to find the second maximum and minimum elements in an array.

Write a Java program to calculate the power of a number using recursion.
Write a Java program to remove duplicate elements from an array.
Write a Java program to find and display duplicate characters in a string.



 */
    }
}
